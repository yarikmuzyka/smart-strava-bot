"""Recommendation rules package."""

